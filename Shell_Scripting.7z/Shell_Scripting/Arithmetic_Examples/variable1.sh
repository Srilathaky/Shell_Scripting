#!/bin/bash
_name=10
echo "$_name"
