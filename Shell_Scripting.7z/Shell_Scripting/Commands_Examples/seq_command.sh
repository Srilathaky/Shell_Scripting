#!/bin/bash
#Using seq command
for i in $(seq 1 2  10)
do
echo $i
done

#USing for looop like C

for(( var=1; var<=5;var++ ))
do
echo $var
done

