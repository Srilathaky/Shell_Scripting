#!/bin/bash
printf "Enter Name"
read name
printf "Enter Age"
read age

printf "Name is %s $name"
printf "\n"
printf "Age is %s  $age"
