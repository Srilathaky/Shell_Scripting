file="/home/srilatha.y/Automation/Shell_Scripting/a"
while ifs=read line
do
echo 



<"$file"
