#!/bin/bash
echo Enter your Name
read name
echo My name is $name
name="sri"
unset name
echo $name
