#!/bin/bash
#Program to display the files which are having name with only one character.
echo `ls ?`
