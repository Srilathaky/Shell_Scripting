#! /bin/bash
for var in 0 1 2 3 4 5
do
echo $var
done
