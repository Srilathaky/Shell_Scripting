#!/bin/bash
for f in *
do
echo $f
done
