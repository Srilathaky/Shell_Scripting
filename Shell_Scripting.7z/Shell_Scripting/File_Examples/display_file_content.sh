#!/bin/bash

a="/home/srilatha.y/Automation/Shell_Scripting/a"
#str=grep -i 'file' $a
#echo $str

echo "**********************************"
echo $a
cat $a

