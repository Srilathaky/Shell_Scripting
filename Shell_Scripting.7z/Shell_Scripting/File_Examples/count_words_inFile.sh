#!/bin/bash
echo `grep -i -c  "Apple" a`
