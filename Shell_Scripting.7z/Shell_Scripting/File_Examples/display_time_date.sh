#!/bin/bash
echo "------------------------------------"
echo "date= `date`"
echo "Current directory= `pwd`"
echo "User=$USER"
