#!/bin/bash
echo Name of the script is $0
echo First parameter is $1
echo Second parameter is $2
echo third parametere is $3
echo Total Number os Arguments are $#
echo PID of the  Script is $$
echo All the parameters $*
echo last reurned value $?

