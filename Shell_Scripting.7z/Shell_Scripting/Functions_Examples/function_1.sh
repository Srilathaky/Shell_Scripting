#!/bin/bash
display(){
echo "HELLO $1"
}

echo "Enter Your Name"
read name
display $name
